<?php

namespace LaravelZero\Framework\Components\Updater\Strategy;

interface StrategyInterface extends \Humbug\SelfUpdate\Strategy\StrategyInterface
{
}
