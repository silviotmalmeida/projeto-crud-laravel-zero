<?php

namespace LaravelZero\Framework\Components\Updater\Strategy;

final class GithubReleasesStrategy extends \Humbug\SelfUpdate\Strategy\GithubStrategy implements StrategyInterface
{
}
