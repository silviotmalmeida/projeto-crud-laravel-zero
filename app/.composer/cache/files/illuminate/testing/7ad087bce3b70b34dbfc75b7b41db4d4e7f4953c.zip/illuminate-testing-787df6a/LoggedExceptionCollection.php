<?php

namespace Illuminate\Testing;

use Illuminate\Support\Collection;

class LoggedExceptionCollection extends Collection
{
    //
}
