<?php

namespace PhpSchool\CliMenu\Exception;

/**
 * @author Michael Woodward <mikeymike.mw@gmail.com>
 */
class InvalidTerminalException extends \Exception
{

}
