<?php

namespace PhpSchool\CliMenu\Exception;

/**
 * @author Aydin Hassan <aydin@hotmail.co.uk>
 */
class MenuNotOpenException extends \RuntimeException
{

}
