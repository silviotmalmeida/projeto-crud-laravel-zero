<h1 align="center">Terminal Utility</h1>

<p align="center">
    Small utility to help provide a simple, consise API for terminal interaction
</p>

<p align="center">
    <a href="https://travis-ci.org/php-school/terminal" title="Build Status" target="_blank">
     <img src="https://img.shields.io/travis/php-school/terminal/master.svg?style=flat-square&label=Linux" />
    </a
    <a href="https://codecov.io/github/php-school/terminal" title="Coverage Status" target="_blank">
     <img src="https://img.shields.io/codecov/c/github/php-school/terminal.svg?style=flat-square" />
    </a>
    <a href="https://scrutinizer-ci.com/g/php-school/terminal/" title="Scrutinizer Code Quality" target="_blank">
     <img src="https://img.shields.io/scrutinizer/g/php-school/terminal.svg?style=flat-square" />
    </a>
    <a href="https://phpschool-team.slack.com/messages">
      <img src="https://phpschool.herokuapp.com/badge.svg">
    </a>
</p>

---

## Install

```bash
composer require php-school/terminal
```

## TODO

- [ ] Docs
